package com.example.dell.expensemanager;
import android.app.DatePickerDialog;
import android.database.Cursor;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import java.util.Calendar;

public class HomeActivity extends AppCompatActivity {
    DatePicker datePicker;
    TextView displayDate;
    Button changeDate;
    int month;

    DatabaseHelper myDb;
    EditText HomePr,HomeNote;
    Button AddHome,RemoveHome,ViewHome;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);

        datePicker = (DatePicker) findViewById(R.id.datePicker);
        displayDate = (TextView) findViewById(R.id.display_date);
        displayDate.setText("Display Date");
        changeDate = (Button) findViewById(R.id.change_date_button);

        myDb = new DatabaseHelper(this);

        HomePr = (EditText)findViewById(R.id.HomePr);
        HomeNote = (EditText)findViewById(R.id.HomeNote);
        AddHome = (Button)findViewById(R.id.AddHome);
       // RemoveHome =(Button) findViewById(R.id.RemoveHome);
        ViewHome=(Button)findViewById(R.id.ViewHome);
        ViewHome();
        AddHome();
        //RemoveHome();
        SelectDate();
    }
    public String currentDate() {
        StringBuilder mcurrentDate = new StringBuilder();
        month = datePicker.getMonth() + 1;
        mcurrentDate.append("Date: " + month + "/" + datePicker.getDayOfMonth() + "/" + datePicker.getYear());
        return mcurrentDate.toString();
    }
    public void SelectDate()
    {
        displayDate.setText(currentDate());
        changeDate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                displayDate.setText(currentDate());
            }
        });

    }
    public  void AddHome() {
        AddHome.setOnClickListener(
                new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        boolean isInserted = myDb.insertData(HomePr.getText().toString(),
                                HomeNote.getText().toString());
                        if(isInserted == true)
                            Toast.makeText(HomeActivity.this,"Home Expense Added",Toast.LENGTH_LONG).show();
                        else
                            Toast.makeText(HomeActivity.this,"Home Expense Not Added ",Toast.LENGTH_LONG).show();
                    }
                }
        );
    }

  /* public void RemoveHome() {
        RemoveHome.setOnClickListener(
                new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        Integer deletedRows = myDb.deleteData(tid.getText().toString());
                        if(deletedRows > 0)
                            Toast.makeText(HomeActivity.this,"Data Deleted",Toast.LENGTH_LONG).show();
                        else
                            Toast.makeText(HomeActivity.this,"Data not Deleted",Toast.LENGTH_LONG).show();
                    }
                }
        );
    }*/
    public void ViewHome() {
        ViewHome.setOnClickListener(
                new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        Cursor res = myDb.getAllData();
                        if(res.getCount() == 0) {
                            // show message
                            showMessage("Error","Nothing found");
                            return;
                        }

                        StringBuffer buffer = new StringBuffer();
                        while (res.moveToNext()) {
                            buffer.append("TId :"+ res.getString(0)+"\n");
                            buffer.append("NOTE :"+ res.getString(1)+"\n");
                            buffer.append("AMOUNT :"+ res.getString(2)+"\n\n");
                        }

                        // Show all data
                        showMessage("Data",buffer.toString());
                    }
                }
        );
    }

    public void showMessage(String title,String Message){
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setCancelable(true);
        builder.setTitle(title);
        builder.setMessage(Message);
        builder.show();
    }
}